package domain

class Data {
    var data : String? = null
}