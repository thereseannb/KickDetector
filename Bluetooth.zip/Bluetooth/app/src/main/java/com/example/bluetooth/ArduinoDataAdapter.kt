//package com.example.bluetooth
//
//import domain.Data
//import com.chad.library.adapter.base.BaseQuickAdapter
//import com.chad.library.adapter.base.BaseViewHolder
//
//class ArduinoDataAdapter(layoutResId: Int, data: List<Data>?): BaseQuickAdapter<Data, BaseViewHolder>(layoutResId, data) {
//}